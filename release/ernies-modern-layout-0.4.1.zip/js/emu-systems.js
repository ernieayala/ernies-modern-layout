export const SYSTEM = [
	'dnd5e',
	'morkborg',
	'sfrpg',
]

export const SYSTEM = [
	'alienrpg',
	'dnd5e',
	'morkborg',
	'sfrpg',
]

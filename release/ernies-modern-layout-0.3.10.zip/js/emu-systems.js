export const SYSTEM = [
	'CoC7',
	'dnd5e',
	'dsa5',
	'fate-core-official',
	'pf1',
	'pf2e',
	'sfrpg',
	'shadowrun5e'
]

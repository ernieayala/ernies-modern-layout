export const SYSTEM = [
	'alienrpg',
	'CoC7',
	'dnd5e',
	'morkborg',
	'pf2e',
	'sfrpg',
	'twodsix'
]
